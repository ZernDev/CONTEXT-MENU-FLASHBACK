
-- https://gtaforums.com/topic/794014-fonts-list/
TextFont = {
	Default     = 0,
	Cursive     = 1,
	Monospace   = 2,
	Symbols     = 3,
	Small       = 4,
	Numbers     = 5,
	Small2      = 6,
	GTA         = 7,

	-- real names
	ChaletLondon            = 0,
	HouseScript             = 1,
	ChaletComprimeCologne   = 4,
	PriceDown               = 7
}
