
TextAlignment = {
	Center  = 0,
	Left    = 1,
	Right   = 2
}
