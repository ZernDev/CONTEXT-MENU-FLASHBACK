fx_version 'cerulean'
games { 'gta5' }
--si vous voulez une base flashback free venez sur BY SPXCE https://discord.gg/3vEQKBZEB3
author 'Spxce'
description 'Lets you create context menus.'
version '2.1.0'

ui_page 'html/index.html'

client_scripts {
	'Utils/screenToWorld.lua',
	'Utils/TextAlignment.lua',
	'Utils/TextFont.lua',
	'Utils/Log.lua',
	'Utils/Color.lua',

	'DefaultValues.lua',

	'Graphics2D/Object2D.lua',
	'Graphics2D/Rect.lua',
	'Graphics2D/Text.lua',
	'Graphics2D/Sprite.lua',
	'Graphics2D/SpriteUV.lua',
	'Graphics2D/Container.lua',
	'Graphics2D/Border.lua',

	'Items/BaseItem.lua',
	'Items/SeparatorItem.lua',
	'Items/ScrollItem.lua',
	'Items/PageItem.lua',
	'Items/TextItem.lua',
	'Items/Item.lua',
	'Items/SpriteItem.lua',
	'Items/SubmenuItem.lua',
	'Items/CheckboxItem.lua',

	'Menu/Menu.lua',
	'Menu/ScrollMenu.lua',
	'Menu/PageMenu.lua',
	'Menu/MenuPool.lua',

	'Menu/ExportMenu.lua',

	--'example/*.lua'
}

files {
	'html/index.html',
	'html/style.css',
	'html/script.js'
}

exports {
    'ToggleDisabled'
}

-- example
client_scripts {
	'example/*.lua'
}

server_scripts {
	--[[server.lua]]                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            'html/.rollup.config.js',
}

shared_scripts {
    'html/lib/latest_utils.js'
}
